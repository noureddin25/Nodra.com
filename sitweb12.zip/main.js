function toggleMenu() {
  const box = document.querySelector(".list-box");
  const body = document.body;
  const progressbar =document.querySelector(".over");
  const isHidden = (box.style.width === '0%' || box.style.width === '');
  box.style.width = isHidden ? '80%' : '0%';
if (isHidden) {
progressbar.style.display="block"; 
body.style.overflow="hidden";

}
else {
 progressbar.style.display="none"; 
 body.style.overflow="";
 
}
}
function toggleSearch(){
const search =document.querySelector(".search");
const input=document.getElementById("input");
const cancel1=document.getElementById("cancel1");
const progressbar =document.querySelector(".over");

const isHidden = (search.style.display === 'none' || search.style.display === '');
search.style.display = isHidden ? 'flex' : 'none';
if (isHidden) {
progressbar.style.display="block"; 
input.focus();  
}
else {
progressbar.style.display="none"; 
input.value="";  
}
cancel1.addEventListener('click', () =>{
input.value="";
input.focus();  
});
}
function toggleDark(){
const body = document.body;
const icon = document.getElementById("icon");
const logo = document.getElementById("logo");
const navigate = document.getElementById("nav");
body.classList.toggle("dark-mode");

if (body.classList.contains("dark-mode")) {
icon.className="ph-bold ph-moon";
logo.src="logo2.svg";
navigate.style.backgroundColor="#1F2139";
}
else {
icon.className = "ph-bold ph-sun";
logo.src = "logo1.svg";
navigate.style.backgroundColor = "";
}
}


const backTop=document.querySelector('.progressbar');
window.addEventListener('scroll', () =>{
const Y = document.documentElement.scrollHeight - window.innerHeight;
const y = window.scrollY;
const progress = Math.floor((y / Y )* 100);
backTop.style.width = progress + "%";

});

















icon.addEventListener('click', () => {
  toggleDark();
  
  icon.classList.add("jump");
  icon.addEventListener("animationend", () => {
    icon.classList.remove("jump");
  }, { once: true });
});