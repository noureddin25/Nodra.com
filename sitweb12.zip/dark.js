function toggleDark(){
const body = document.body;
const icon = document.getElementById("icon");
const logo = document.getElementById("logo");
const navigate = document.getElementById("nav");
body.classList.toggle("dark-mode");

if (body.classList.contains("dark-mode")) {
icon.className="ph-bold ph-moon";
logo.src="logo2.svg";
navigate.style.backgroundColor="#1F2139";
}
else {
icon.className = "ph-bold ph-sun";
logo.src = "logo1.svg";
navigate.style.backgroundColor = "";
}






}
icon.addEventListener('click',() =>{
toggleDark();
icon.classList.add("jump");
icon.addEventListener("animationend", () => {
icon.classList.remove("jump");
}, { once: true });
});
